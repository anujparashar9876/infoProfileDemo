

import 'package:infoprofiledemo/data/network/base_api_service.dart';
import 'package:infoprofiledemo/data/network/network_api_service.dart';
import 'package:infoprofiledemo/res/app_url.dart';

class AuthRepository{
  BaseApiServices _apiServices=NetworkApiServices();

  Future<dynamic> loginApi(dynamic data) async{
    try{
      dynamic response=await _apiServices.getPostApiResponse(AppUrl.loginurl, data);
      return response;
    } catch(e){
      throw e;
    }
  }

  Future<dynamic> registerApi(dynamic data) async{
    try{
      dynamic response=await _apiServices.getPostApiResponse(AppUrl.registerurl, data);
      return response;
    } catch(e){
      throw e;
    }
  }
}