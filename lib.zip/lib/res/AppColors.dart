import 'package:flutter/material.dart';

class AppColors {
  // static const theme=Color.fromARGB(255, 23, 167, 155);
  static const theme=Color.fromARGB(255, 29, 86, 57);
  static const white=Colors.white;
  static const black=Colors.black;
}