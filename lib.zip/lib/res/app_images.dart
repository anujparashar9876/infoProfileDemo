class AppImages{
  static const otp="assets/otp.png";
  static const login="assets/login.gif";
  static const login2="assets/login-2.gif";
  static const signup="assets/signup.gif";
  static const forgetPassword="assets/forgetPassword.gif";
  static const a="assets/1.gif";
  static const create="assets/b.png";
  static const firstTut="assets/first_tutorial.gif";
  static const secondTut="assets/second_tutorial.gif";
  static const connect="assets/connect.png";
  static const share="assets/shareMemory.png";
  static const land="assets/landscape.jpeg";
}