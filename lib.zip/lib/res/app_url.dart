class AppUrl{
  static var baseUrl='http://192.168.2.187:3001';
  static var loginurl=baseUrl+'/api/login';
  static var registerurl=baseUrl+'/user/postV1UserRequestsignup'; 
}