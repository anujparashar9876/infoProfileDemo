class RouteName{
  static const splash="Splash Screen";
  static const login="Login Screen";
  static const signup="Signup screen";
  static const complete="Complete Profile";
  static const forget="Forget Password Screen";
  static const otpfoget="Forget Password OTP screen";
  static const otp="OTP Screen";
  static const newpass="New Password Screen";
  static const profile="Profile screen";
  static const home="Home Screen";
  static const bottomNav="Bottom Navigation Bar";
  static const createPost="Create Post Screen";
  static const firstTutorial="First Tutorial Screen";
}