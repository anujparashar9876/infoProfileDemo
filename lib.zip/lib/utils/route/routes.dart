import 'package:flutter/material.dart';
import 'package:infoprofiledemo/res/component/bottom_navigation_bar.dart';
import 'package:infoprofiledemo/utils/route/routeName.dart';
import 'package:infoprofiledemo/view/Auth/complete_profile_screen.dart';
import 'package:infoprofiledemo/view/Auth/forget_password_screen.dart';
import 'package:infoprofiledemo/view/Auth/login_screen.dart';
import 'package:infoprofiledemo/view/Auth/new_password_screen.dart';
import 'package:infoprofiledemo/view/Auth/otp_screen.dart';
import 'package:infoprofiledemo/view/Auth/otp_screen_forget_screen.dart';
import 'package:infoprofiledemo/view/Auth/signup_screen.dart';
import 'package:infoprofiledemo/view/create_post_screen.dart';
import 'package:infoprofiledemo/view/home_screen.dart';
import 'package:infoprofiledemo/view/profile_screen.dart';
import 'package:infoprofiledemo/view/splashScreen.dart';
import 'package:infoprofiledemo/view/tutorial_screen/first_tutorial_screen.dart';

class Routes {
  static Route<dynamic> generateRoute(RouteSettings settings){
    switch (settings.name) {
      case RouteName.splash:
        return MaterialPageRoute(builder: (context)=>SplashScreen());
      case RouteName.login:
        return MaterialPageRoute(builder: (context)=>LoginScreen());
      case RouteName.signup:
        return MaterialPageRoute(builder: (context) =>SignUpScreen());
      case RouteName.complete:
        return MaterialPageRoute(builder: (context)=>CompleteProfileScreen());
      case RouteName.otp:
        // Map<String, dynamic> otp= settings.arguments as Map<String, dynamic>;
        return MaterialPageRoute(builder: (context)=>OTPScreen());
      case RouteName.forget:
        return MaterialPageRoute(builder: (context)=>ForgetPasswordScreen());
      case RouteName.otpfoget:
        return MaterialPageRoute(builder: (context)=>OTPForgetScreen());
      case RouteName.newpass:
        return MaterialPageRoute(builder: (context)=>NewPasswordScreen());
      case RouteName.profile:
        return MaterialPageRoute(builder: (context)=>UserProfileScreen());
      case RouteName.home:
        return MaterialPageRoute(builder: (context)=>HomeScreen());
      case RouteName.bottomNav:
        return MaterialPageRoute(builder: (context)=>BottomNavigation());
      case RouteName.createPost:
        return MaterialPageRoute(builder: (context)=>CreatePostScreen());
      case RouteName.firstTutorial:
        return MaterialPageRoute(builder: (context)=>FirstTutorialScreen());
      default:
      return MaterialPageRoute(builder: (context){
        return Scaffold(
          body: Center(child: Text('No Route Found'),),
        );
      });
    }
  }
}