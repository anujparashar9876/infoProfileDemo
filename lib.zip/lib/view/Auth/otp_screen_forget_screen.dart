import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:infoprofiledemo/res/AppColors.dart';
import 'package:infoprofiledemo/res/AppString.dart';
import 'package:infoprofiledemo/res/app_images.dart';
import 'package:infoprofiledemo/res/component/buttonCustom.dart';
import 'package:infoprofiledemo/res/string_text_style.dart';
import 'package:infoprofiledemo/utils/route/routeName.dart';

class OTPForgetScreen extends StatefulWidget {
  
  OTPForgetScreen({super.key});

  @override
  State<OTPForgetScreen> createState() => _OTPForgetScreenState();
}

class _OTPForgetScreenState extends State<OTPForgetScreen> {
  @override
  Widget build(BuildContext context) {
    // List<TextEditingController> otpController=List.generate(5, (index) => TextEditingController());
    // List<FocusNode> focus=List.generate(5, (index) => FocusNode());
    return Scaffold(
      appBar: AppBar(title: Text(AppString.otptitle),),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(AppImages.otp,scale: 0.4,),
          Text(AppString.verify,style: StringTextStyle.title,),
          Text(AppString.verifyInfo),
          // Row(
          //   children: List.generate(4, (index) => Container(
          //     margin: EdgeInsets.symmetric(horizontal: 20,),
          //     width: MediaQuery.of(context).size.width*0.15,              
          //     child: TextField(
          //       maxLength: 1,
          //       controller: otpController[index],
          //       focusNode: focus[index],
          //       textAlign: TextAlign.center,
          //       keyboardType: TextInputType.number,
          //       decoration: InputDecoration(
          //         enabledBorder: OutlineInputBorder(
          //           borderRadius: BorderRadius.circular(40),
          //         ),
          //         focusedBorder: OutlineInputBorder(),
          //       ),
          //       onChanged: (value) {
          //         if (value.isNotEmpty) {
          //           if (index<4) {
          //             focus[index+1].requestFocus();
          //           }else{

          //           }
          //         }
          //       },
          //       onSubmitted: (value) {
                  
          //       },
          //     ),
          //   )),
          // ),
          
          CupertinoButton(child: Text('Resend OTP'), onPressed: (){}),
          OtpTextField(
            fieldWidth: 50,
            margin: EdgeInsets.all(20),
            numberOfFields: 4,
            borderColor: Color(0xFF512DA8),
            //set to true to show as box or false to show as dash
            showFieldAsBox: true,
            //runs when a code is typed in
            onCodeChanged: (String code) {
              //handle validation or checks here
            },
            //runs when every textfield is filled
            onSubmit: (String verificationCode) {
              showDialog(
                  context: context,
                  builder: (context) {
                    return AlertDialog(
                      title: Text("Verification Code"),
                      content: Text('Code entered is $verificationCode'),
                    );
                  });
            }, // end onSubmit
          ),
          
          SubmitButton(
            textCol: AppColors.white, 
            he: MediaQuery.of(context).size.height*0.05,
            wi: MediaQuery.of(context).size.width*0.9,
            buttonLabel: AppString.veri,
            col: AppColors.theme,
            submitFuction: () {
              
              Navigator.pushNamed(context, RouteName.newpass);
            },
            ),


      ],),
    );
  }
}