import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:infoprofiledemo/res/AppColors.dart';
import 'package:infoprofiledemo/res/AppString.dart';
import 'package:infoprofiledemo/res/app_images.dart';
import 'package:infoprofiledemo/res/component/buttonCustom.dart';
import 'package:infoprofiledemo/res/component/text_field_custom.dart';
import 'package:infoprofiledemo/res/regExp.dart';
import 'package:infoprofiledemo/res/string_text_style.dart';
import 'package:infoprofiledemo/utils/route/routeName.dart';
import 'package:infoprofiledemo/view_model/provider/obsecure_provider.dart';
import 'package:provider/provider.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  TextEditingController usernameController=TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passController = TextEditingController();
  TextEditingController confirmpasswordController = TextEditingController();
  
  @override
  Widget build(BuildContext context) {
    final obsecureProvider=Provider.of<ObsecureProvider>(context);
    return Scaffold(
      // appBar: AppBar(
      //   title: Text(AppString.signup),
      // ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Image.asset(AppImages.signup,scale: 2,),
                    Text(
                      AppString.appName,
                      style: StringTextStyle.title
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height*0.05,
                    ),
                    TextFieldCustom(
                      control: usernameController,
                      preIcon: Icons.person,
                      obsecure: false, 
                      hint: AppString.username,
                      labeltext: AppString.username,
                      validate: (value){
                        if (usernameController.text.isEmpty ||
                            !RegExp(RegEx.userNameRegexp)
                                .hasMatch(usernameController.text)) {
                          return AppString.fieldmust;
                        }else {
                          return null;
                        }
                    }),
                    SizedBox(height: 20,),
                    TextFieldCustom(
                      control: emailController,
                      preIcon: Icons.email_outlined,
                      obsecure: false,
                      hint: AppString.emailHint,
                      labeltext: AppString.emailLabel,
                      validate: (value) {
                        if (emailController.text.isEmpty ||
                            !RegExp(RegEx.emailRegExp)
                                .hasMatch(emailController.text)) {
                          return AppString.fieldmust;
                        } else if (!emailController.text.contains('@')) {
                          return AppString.require;
                        } else {
                          return null;
                        }
                      },
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height*0.025,
                    ),
                    TextFieldCustom(
                      control: passController,
                      preIcon: Icons.lock,
                      suficon: obsecureProvider.ob?Icons.visibility:Icons.visibility_off,
                      sufFunction: (){obsecureProvider.obsecure();},
                      validate: (value) {
                        if (passController.text.isEmpty) {
                          return AppString.passrequire;
                        } else if (RegExp(
                                RegEx.passRegExp)
                            .hasMatch(passController.text)) {
                          return AppString.invalid;
                        } else {
                          return null;
                        }
                      },
                      obsecure: !obsecureProvider.ob,
                      hint: AppString.pass,
                      labeltext: AppString.pass,
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height*0.025,
                    ),
                    TextFieldCustom(
                      control: confirmpasswordController,
                      preIcon: Icons.lock,
                      obsecure: !obsecureProvider.ob,
                      suficon: obsecureProvider.ob?Icons.visibility:Icons.visibility_off,
                      sufFunction: (){obsecureProvider.obsecure();},
                      hint: AppString.cPass,
                      labeltext: AppString.cPass,
                      validate: (value) {
                        if (confirmpasswordController.text.isEmpty) {
                          return AppString.fieldmust;
                        } else if (confirmpasswordController.text !=
                            passController.text) {
                          return AppString.noMatch;
                        } else {
                          return null;
                        }
                      },
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height*0.025,
                    ),
                    SubmitButton(
                      buttonLabel: AppString.signup,
                      col: AppColors.theme,
                      submitFuction: () {
                        Navigator.pushNamed(context, RouteName.otp);
                        // Navigator.pushNamed(context, RouteName.complete);
                      },
                      textCol: AppColors.white,
                      he: MediaQuery.of(context).size.height*0.05,
                      wi: MediaQuery.of(context).size.width*0.9,
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height*0.06,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(AppString.doAccount,style: StringTextStyle.account),
                        CupertinoButton(child: Text(AppString.login), onPressed:() {
                            Navigator.pushNamed(context, RouteName.login);
                          },)
                        
                      ],
                    ),]),
        ),
      ),
    );
  }
}