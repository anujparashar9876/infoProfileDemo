import 'package:flutter/material.dart';
import 'package:infoprofiledemo/res/AppString.dart';
import 'package:infoprofiledemo/view/post_design.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(AppString.home),),
    body: SingleChildScrollView(
      child: Column(children: [
        PostDesign(),
        PostDesign(),
        PostDesign(),
        PostDesign(),
        PostDesign(),
        PostDesign(),
      ],),
    ),
    );
  }
}