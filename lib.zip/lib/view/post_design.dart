import 'package:flutter/material.dart';
import 'package:infoprofiledemo/res/AppColors.dart';
import 'package:infoprofiledemo/res/app_images.dart';

class PostDesign extends StatefulWidget {
  const PostDesign({super.key});

  @override
  State<PostDesign> createState() => _PostDesignState();
}

class _PostDesignState extends State<PostDesign> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.all(10),
      decoration: BoxDecoration(
          border: Border.all(width: 0.1),
          borderRadius: BorderRadius.circular(20),
          color: AppColors.theme.withOpacity(0.15)),
      child: Column(
        children: [
          SizedBox(
            height: 5,
          ),
          Row(
            children: [
              SizedBox(
                width: 15,
              ),
              CircleAvatar(
                backgroundImage: AssetImage(AppImages.otp),
              ),
              SizedBox(
                width: 20,
              ),
              Text(
                "Anuj Kumar Parashar",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(
                width: MediaQuery.of(context).size.width*0.3,
              ),
              IconButton(
                icon: Icon(Icons.more_vert),
                onPressed: () {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (BuildContext context) {
                      return Dialog(
                        alignment: Alignment.topRight,
                        insetPadding: EdgeInsets.only(left: 5, top: 20),
                        child: Container(
                          width: 100,
                          child: ListTile(
                            title: Text("alert!"),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ],
          ),
          SizedBox(
            height: 5,
          ),
          Container(
            margin: EdgeInsets.all(5),
            height: MediaQuery.of(context).size.height * 0.3,
            width: MediaQuery.of(context).size.width * 1,
            child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Image.asset(
                  AppImages.land,
                  fit: BoxFit.fill,
                )),
          ),
          SizedBox(
            height: 10,
          ),
          Row(
            children: [
              SizedBox(
                width: 10,
              ),
              Container(
                  padding: EdgeInsets.only(left: 4, right: 4),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(width: 0.5),
                      color: AppColors.theme),
                  child: Row(
                    children: [
                      Icon(
                        Icons.favorite_border,
                        color: AppColors.white,
                      ),
                      SizedBox(
                        width: 2,
                      ),
                      Text(
                        '123k',
                        style: TextStyle(color: AppColors.white),
                      ),
                    ],
                  )),
              SizedBox(
                width: 10,
              ),
              Container(
                  padding: EdgeInsets.only(left: 4, right: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(width: 0.5),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.comment),
                      SizedBox(
                        width: 2,
                      ),
                      Text('123k'),
                    ],
                  )),
              SizedBox(
                width: 10,
              ),
              Container(
                  padding: EdgeInsets.only(left: 4, right: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(width: 0.5),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.share),
                      SizedBox(
                        width: 2,
                      ),
                      Text('123k'),
                    ],
                  )),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Text(
                "Nature, in the broadest sense, is the physical world or universe. Nature can refer to the phenomena of the physical world, and also to life in general."),
          ),
        ],
      ),
    );
  }
}
