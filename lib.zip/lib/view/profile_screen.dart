import 'package:flutter/material.dart';
import 'package:infoprofiledemo/res/AppColors.dart';
import 'package:infoprofiledemo/res/AppString.dart';
import 'package:infoprofiledemo/res/app_images.dart';
import 'package:infoprofiledemo/res/string_text_style.dart';
import 'package:infoprofiledemo/utils/route/routeName.dart';


class UserProfileScreen extends StatefulWidget {
  const UserProfileScreen({super.key});

  @override
  State<UserProfileScreen> createState() => _UserProfileScreenState();
}

class _UserProfileScreenState extends State<UserProfileScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(),
          Positioned(
            top: MediaQuery.of(context).size.height*-0.4,
            left: MediaQuery.of(context).size.width*-0.213,
            child: RotationTransition(
            turns: AlwaysStoppedAnimation(45/360),
            child: Container(
              height: MediaQuery.of(context).size.height*0.75,
              width: MediaQuery.of(context).size.width*1.5,
              decoration: BoxDecoration(
                color: AppColors.theme.withOpacity(0.5),
                borderRadius: BorderRadius.circular(MediaQuery.of(context).size.width*0.45)
              ),
            ),
          )),
          Column(
            children: [
              Padding(
                padding: EdgeInsets.only(top: MediaQuery.of(context).size.height*0.055),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    CircleAvatar(radius: 60,backgroundImage: AssetImage(AppImages.land),),
                    SizedBox(height: MediaQuery.of(context).size.height*0.02,),
                    Text("Anuj Kumar Parashar",style: StringTextStyle.profile,),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.all(MediaQuery.of(context).size.width*0.05),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                  Column(
                        children: [Text("27"), Text(AppString.post)],
                      ),
                      Column(
                        children: [Text("103M"), Text(AppString.follower)],
                      ),
                      Column(
                        children: [Text("123"), Text(AppString.following)],
                      ),
                ],),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height*0.03,
              ),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: InkWell(
                  onTap: () {
                    // Navigator.pushNamed(context, RouteName.editProfile);
                  },
                  child: Container(
                    height: MediaQuery.of(context).size.height * 0.04,
                    width: MediaQuery.of(context).size.width*0.4,
                    decoration: BoxDecoration(
                        color: AppColors.white,
                        border: Border.all(color: AppColors.theme.withOpacity(0.5)),
                        borderRadius: BorderRadius.circular(15)),
                    child: const Center(child: Text(AppString.follow)),
                  ),
                ),
              ),
              
              const SizedBox(
                height: 35,
              ),
              Expanded(
                child: GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 0,
                    mainAxisSpacing: 0,
                  ),
                  itemCount: 30,
                  itemBuilder: (BuildContext context, int index) {
                    return Container(
                      margin: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: AppColors.theme,
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset(AppImages.land,fit: BoxFit.cover,),
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}
