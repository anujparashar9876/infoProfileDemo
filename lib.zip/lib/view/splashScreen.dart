import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:infoprofiledemo/res/AppColors.dart';
import 'package:infoprofiledemo/res/app_images.dart';
import 'package:infoprofiledemo/utils/route/routeName.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {@override
  void initState() {
    // TODO: implement initState
    super.initState();
    Future.delayed(Duration(seconds: 4
    ),(){
      Navigator.pushReplacementNamed(context, RouteName.firstTutorial);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      
      body: Container(
        height: double.maxFinite,
        width: double.maxFinite,
        decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [
                0.5,
                1
              ],
              colors: [
          Color.fromARGB(255, 254, 249, 233),
          Color.fromARGB(255, 228, 189, 129),
        ])),
        child: Center(child: Image.asset(AppImages.login),)),
    );
  }
}