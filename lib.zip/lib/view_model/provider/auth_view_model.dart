import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:infoprofiledemo/repository/auth_repository.dart';
import 'package:infoprofiledemo/utils/route/routeName.dart';
import 'package:infoprofiledemo/utils/utils.dart';


class AuthViewModel with ChangeNotifier{
  final _myRepo=AuthRepository();

  bool _loading=false;
  bool get loading=>_loading;

  setLoading(bool value){
    _loading=value;
    notifyListeners();
  }

  Future<void> loginApi(dynamic data,BuildContext context) async{
    setLoading(true);
    _myRepo.loginApi(data).then((value){
      if(kDebugMode){
        setLoading(false);
        Utils.snackBar("Login Successful", context);
        Navigator.pushNamed(context,RouteName.home);
        print(value.toString());

      }
    }).onError((error, stackTrace){
      setLoading(false);
      if(kDebugMode){
        Utils.flushBarErrorMessage(error.toString(),context);
        print(error.toString());
      }
    });
  }

  Future<void> registerApi(dynamic data,BuildContext context) async{
    setLoading(true);
    _myRepo.registerApi(data).then((value){
      if(kDebugMode){
        setLoading(false);
        Utils.snackBar("Register Successful", context);
        Navigator.pushNamed(context,RouteName.home);
        print(value.toString());

      }
    }).onError((error, stackTrace){
      setLoading(false);
      if(kDebugMode){
        Utils.flushBarErrorMessage(error.toString(),context);
        print(error.toString());
      }
    });
  }
}