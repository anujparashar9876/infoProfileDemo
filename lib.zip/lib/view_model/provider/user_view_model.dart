// import 'package:flutter/material.dart';
// import 'package:infoprofiledemo/model/signup_user_model.dart';
// import 'package:shared_preferences/shared_preferences.dart';


// class UserViewModel with ChangeNotifier{
//   Future <bool> saveUser(signUp_user_model user) async{
//     final SharedPreferences sp =await SharedPreferences.getInstance();
//     sp.setString('token', user.token.toString());
//     notifyListeners();
//     return true;
//   }

//   Future<UserModel> getUser() async{
//     final SharedPreferences sp=await SharedPreferences.getInstance();
//     final String? token=sp.getString('token');
//     return UserModel(token: token.toString());
//   }

//   Future<bool> remove() async{
//     final SharedPreferences sp=await SharedPreferences.getInstance();
//     sp.remove('token');
//     return true;
//   }
// }